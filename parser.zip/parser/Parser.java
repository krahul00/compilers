package parser;
import scanner.Scanner;
import java.io.*;
import java.util.*;

/**
 * Parser is a simple parser for Compilers and Interpreters
 * @author Rahul Mehta
 * @version Version 1, September 27, 2017
 * Usage: This parser is responsible for reading an input stream of tokens,
 * applying a context-free grammar, and producing either values or a 
 * parser table for variables
 */
public class Parser
{
    public Scanner scanner; //be able to get the input streams of token
    String currentToken; //contains the currenttoken
    Map <String, Integer> hashmap = new 
        HashMap <String, Integer>(); //map, or the 
            //parser table, and it contains vars
    /**
     * This is the constructor for the Parser. It takes in a Scanner and 
     * stores it to an instance variable. Additionally, it calls the 
     * Scanner's next method, to set the pointer of currentToken to the 
     * first token.
     * Usage: Parser parser = new Parser(scanner);
     * @param scannertouse the scanner that is passed to the constructor
     */
    public Parser(Scanner scannertouse)
    {
        scanner = scannertouse; //setting the param to the instance var
        try 
        {
            currentToken = scannertouse.nextToken(); //calls nextToken
        }
        catch (Exception e)
        {
            System.out.println("You have a scanErrorException." +
                "Something is wrong with your constructor or scanner");
        }
    }

    /**
     * The eat method takes in a String representing the expected token. 
     * If the expected token matches the current token, then eat asks the
     * Scanner for the next token and stores that as the current token. 
     * @param expectedtoken the expectedtoken you compare to the currentToken
     * Usage: eat(currentToken);
     */
    public void eat(String expectedtoken) throws IllegalArgumentException
    {
        if (currentToken.equals(expectedtoken))
        {
            try
            {
                currentToken = scanner.nextToken(); //sets currentToken to the
                //next Token
            }
            catch (Exception e)
            {
                System.out.println("Hi, you have a scanErrorException");
            }
        }
        else
        {
            throw new 
                IllegalArgumentException (expectedtoken 
                    + "expected, but found " + currentToken);
        }
    }

    /**
     * If the current token is an integer and parseNumber is called, the 
     * number token will be eaten
     * Usage: parseNumber();
     * @return he value of the parsed integer will
     * be returned
     */
    private int parseNumber()
    {
        int num = Integer.parseInt(currentToken);
        eat(currentToken);
        return num;
    }

    /**
     * parseFactor kicks in when there is a -, (, or a variable.
     * If there a -, it multiplies a -1 to the value of the recursively
     * called expression. If there is a '(', it eats that token and parses
     * the value of the resulting expression. If there is a variable, it 
     * retrieves the value from the parse-table and returns it
     * @return value of the parsed factor
     * Usage: parseFactor();
     */
    public int parseFactor()
    {
        if (currentToken.equals("-"))
        {
            eat("-");
            return (-1 * parseFactor());
        }
        else if (currentToken.equals("("))
        {
            int value;
            eat("(");
            value = parseExpression();
            eat(")");
            return value;
        }
        else if (isLetter(currentToken.charAt(0)))
        {
            int x = hashmap.get(currentToken);
            eat(currentToken);
            return x;
        }
        else
        {
            return parseNumber();
        }    
    }

    /**
     * Takes in a char and returns a boolean depending on
     * whether or not the character is a letter. 
     * @Usage: isLetter(currentChar);
     * @param c the currentChar that the method tries to identify
     * whether or not it is a letter
     * @return true if param is a letter
     *         false if param is not a letter
     */
    public static boolean isLetter(char c)
    {
        return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
    }

    /**
     * parseStatement() eats all tokens associated with the WRITELN 
     * statement. Additionally, parseStatement() uses System.out.println 
     * to print the value of the number being printed. Also, the method 
     * eats all tokens associated with a BEGIN/END block, as well as
     * calling the correct method if a variable is present.
     * Usage: parseStatement();
     */
    public void parseStatement()
    {

        if (currentToken.equals("WRITELN"))
        {
            eat("WRITELN");
            eat("(");
            int value = parseExpression();
            eat(")");
            eat(";");
            System.out.println(value);
        }
        else if (currentToken.equals("BEGIN"))
        {
            eat("BEGIN");
            while (!(currentToken.equals("END")))
            {
                parseStatement();
            }
            eat("END");
            eat(";");
        }
        else
        {
            String var = currentToken;
            eat(currentToken);
            eat(":=");
            int value = parseExpression();
            eat(";");
            hashmap.put(var, value);
        }
    }

    /**
     * parseTerm() is enacted when there is a * or a /. If there is a
     * *, then it multiples the current value to the value of the recursively
     * called factor. If there is a /, it divides the current value with the
     * value of the recursively called factor.
     * @return the value of the parsed factor
     * Usage parseTerm()
     */
    public int parseTerm()
    {
        int value = parseFactor();
        while (currentToken.equals("*") || currentToken.equals("/"))
        {
            if (currentToken.equals("*"))
            {
                eat("*");
                value = value * parseFactor();
            }
            if (currentToken.equals("/"))
            {
                eat("/");
                value = value / parseFactor();
            }
        }
        return value;
    }

    /**
     * parseExpression() takes care of the situation when a '+' or
     * a '-' is present. In essence, it uses recursion to add/subtract 
     * the value to whatever the value of the recursively called 
     * parseTerm will return.
     * @return the integer value of the full term at that point
     * Usage parseExpression()
     */
    public int parseExpression()
    {
        int value = parseTerm();
        while (currentToken.equals("+") || currentToken.equals("-"))
        {
            if (currentToken.equals("+"))
            {
                eat("+");
                value = value + parseTerm();
            }
            if (currentToken.equals("-"))
            {
                eat("-");
                value = value - parseTerm();
            }
        }
        return value;
    }

     /**
     * Tester for the code
     * @param args stack
     */
    public static void main (String [] args) throws Exception
    {  
        /* /Users/rahulmehta/Documents/Documents 
         * - Rahul’s MacBook Air/CS/Scanner Lab/parser/
         */
        FileInputStream inStream = 
            new FileInputStream (new File("parserTest4.txt"));
        Scanner scanner = new Scanner(inStream); 
        Parser parser = new Parser(scanner);
        while (scanner.hasNext())
        {
            parser.parseStatement();
        }
    }
}
